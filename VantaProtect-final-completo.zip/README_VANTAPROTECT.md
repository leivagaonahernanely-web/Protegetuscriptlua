# VantaProtect completo

Este paquete contiene el proyecto Flask/Python completo con bot de Discord, dashboard premium, protección Lua y loader compatible con `script_key`.

## Estructura

```text
app.py                 Backend Flask, autenticación, API y loaders
bot.py                 Bot de Discord
lua_protector.py       Limpieza, minificación y renombrado conservador de locales
templates/             Landing, dashboard, scripts, keys, panel y vistas
requirements.txt       Dependencias Python
Procfile               Comando de inicio para Railway
runtime.txt            Versión de Python
```

## Variables de Railway

Configura estas variables en el servicio principal:

```text
SECRET_KEY=tu_secreto_largo
DATABASE_URL=${{Postgres.DATABASE_URL}}
DISCORD_CLIENT_ID=tu_client_id
DISCORD_CLIENT_SECRET=tu_client_secret
DISCORD_BOT_TOKEN=tu_bot_token
ADMIN_DISCORD_ID=tu_discord_id
DOMINIO=https://tu-dominio.up.railway.app
```

El callback de Discord debe apuntar a:

```text
https://tu-dominio.up.railway.app/callback
```

No guardes tokens ni secretos dentro del repositorio ni del ZIP.

## Loader generado

El formato público generado por la plataforma es:

```lua
script_key = "TU_KEY"

loadstring(game:HttpGet("https://tu-dominio.up.railway.app/scripts/hosted/TU_HASH.lua"))()
```

La ruta pública obtiene el `script_key`, solicita el HWID y valida la licencia contra `/api/load/<hash_id>` antes de entregar el código Lua protegido.

## Despliegue en Railway

1. Sube todos los archivos del ZIP a la raíz del repositorio de GitHub.
2. Conecta el repositorio desde Railway.
3. Agrega las variables de entorno.
4. Añade PostgreSQL al proyecto y usa la referencia `DATABASE_URL=${{Postgres.DATABASE_URL}}`.
5. Railway usará el `Procfile` para iniciar la aplicación.
6. Genera un dominio público y usa ese valor en `DOMINIO`.

## Nota sobre la protección

El protector elimina comentarios, conserva strings, minifica espacios y renombra locales simples antes de comprimir el contenido. El sistema también valida key, HWID, expiración, estado activo y baneos. Esto es una protección de código conservadora, no una VM Luau ni un ofuscador nativo equivalente a Luarmor.
